//3
//Using Command Line Argument  perform factorial 

import java.io.*;
import java.util.Scanner;

class Factorial_Argument_TCI1_3
{
	
}